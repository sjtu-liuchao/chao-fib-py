# chao-fib-py
This is a basic pip module on calculating Fibonacci numbers
