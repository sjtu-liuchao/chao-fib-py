def say_hello() -> None:
    print("the Chao Fibonacci module is saying hello")
